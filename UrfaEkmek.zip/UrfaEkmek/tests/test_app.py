"""UrfaEkmek testleri.

Çalıştırma (ikisi de olur):
    python -m unittest discover -s tests -v
    pytest
"""

import os
import sys
import tempfile
import unittest
from datetime import datetime
from unittest.mock import patch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import app as urfa  # noqa: E402
from werkzeug.security import generate_password_hash  # noqa: E402

SIFRE = "sifre123"


def saat(saat_, dakika=0):
    return datetime(2026, 9, 19, saat_, dakika, tzinfo=urfa.TURKIYE_SAATI)


class TestTabani(unittest.TestCase):
    """Her testten önce geçici bir veritabanı ve test tarayıcısı hazırlar."""

    def setUp(self):
        self.klasor = tempfile.TemporaryDirectory()
        urfa.app.config["DATABASE"] = os.path.join(self.klasor.name, "test.db")
        urfa.app.config["TESTING"] = True
        urfa.veritabani_hazirla()
        self.istemci = urfa.app.test_client()

        # Varsayılan olarak saat 12:00 (fırınlar açık)
        self.saat_yamasi = patch.object(urfa, "simdi_turkiye", return_value=saat(12))
        self.saat_yamasi.start()

    def tearDown(self):
        self.saat_yamasi.stop()
        self.klasor.cleanup()

    # ----- yardımcılar -----

    def sorgu(self, sql, parametre=()):
        import sqlite3

        db = sqlite3.connect(urfa.app.config["DATABASE"])
        db.row_factory = sqlite3.Row
        try:
            return db.execute(sql, parametre).fetchall()
        finally:
            db.close()

    def calistir(self, sql, parametre=()):
        import sqlite3

        db = sqlite3.connect(urfa.app.config["DATABASE"])
        try:
            imlec = db.execute(sql, parametre)
            db.commit()
            return imlec.lastrowid
        finally:
            db.close()

    def firin_ekle(self, ad="Test Fırın", saatler="06:00 - 20:00", durum="Onaylandı", kullanici="firin1"):
        return self.calistir(
            "INSERT INTO firin_basvurulari (firin_adi, yetkili, telefon, adres, saatler, "
            "bolgeler, kullanici_adi, sifre, durum) VALUES (?, 'Yetkili', '0555', 'Adres', ?, "
            "'Haliliye', ?, ?, ?)",
            (ad, saatler, kullanici, generate_password_hash(SIFRE), durum),
        )

    def kurye_ekle(self, kullanici="kurye1", durum="Onaylandı"):
        return self.calistir(
            "INSERT INTO kurye_basvurulari (ad_soyad, telefon, yas, ilce, arac, kullanici_adi, "
            "sifre, durum) VALUES ('Kurye Kişi', '0555', 25, 'Haliliye', 'Motosiklet', ?, ?, ?)",
            (kullanici, generate_password_hash(SIFRE), durum),
        )

    def siparis_ekle(self, firin_id, durum="Bekliyor", kurye_id=None):
        return self.calistir(
            "INSERT INTO siparisler (ad_soyad, telefon, adres, urunler, urun_toplami, "
            "kurye_ucreti, genel_toplam, durum, kurye_id, firin_id) VALUES "
            "('Müşteri', '0555', 'Müşteri adresi', '1 x Tırnaklı Ekmek', 15, 30, 45, ?, ?, ?)",
            (durum, kurye_id, firin_id),
        )

    def sepete_ekle(self, istemci, firin_id, urun_id, takip=True):
        return istemci.post(
            f"/sepete-ekle/{urun_id}", data={"firin_id": firin_id}, follow_redirects=takip
        )

    def firinci_giris(self, kullanici="firin1"):
        istemci = urfa.app.test_client()
        yanit = istemci.post("/firinci-giris", data={"kullanici_adi": kullanici, "sifre": SIFRE})
        self.assertEqual(yanit.status_code, 302)
        return istemci

    def kurye_giris(self, kullanici="kurye1"):
        istemci = urfa.app.test_client()
        yanit = istemci.post("/kurye-giris", data={"kullanici_adi": kullanici, "sifre": SIFRE})
        self.assertEqual(yanit.status_code, 302)
        return istemci

    def admin_giris(self):
        istemci = urfa.app.test_client()
        yanit = istemci.post("/admin", data={"kullanici_adi": "admin", "sifre": "1234"})
        self.assertEqual(yanit.status_code, 302)
        return istemci

    def metin(self, yanit):
        return yanit.get_data(as_text=True)


class TestSaatler(unittest.TestCase):
    def test_gunduz_vardiyasi(self):
        self.assertTrue(urfa.firin_acik_mi("06:00 - 20:00", saat(6, 0)))
        self.assertTrue(urfa.firin_acik_mi("06:00 - 20:00", saat(19, 59)))
        self.assertFalse(urfa.firin_acik_mi("06:00 - 20:00", saat(20, 0)))
        self.assertFalse(urfa.firin_acik_mi("06:00 - 20:00", saat(5, 59)))

    def test_gece_vardiyasi(self):
        self.assertTrue(urfa.firin_acik_mi("22:00 - 06:00", saat(22, 0)))
        self.assertTrue(urfa.firin_acik_mi("22:00 - 06:00", saat(23, 30)))
        self.assertTrue(urfa.firin_acik_mi("22:00 - 06:00", saat(0, 0)))
        self.assertTrue(urfa.firin_acik_mi("22:00 - 06:00", saat(5, 59)))
        self.assertFalse(urfa.firin_acik_mi("22:00 - 06:00", saat(6, 0)))
        self.assertFalse(urfa.firin_acik_mi("22:00 - 06:00", saat(12, 0)))

    def test_bozuk_saat_kapali_sayilir(self):
        self.assertFalse(urfa.firin_acik_mi("", saat(12)))
        self.assertFalse(urfa.firin_acik_mi(None, saat(12)))
        self.assertFalse(urfa.firin_acik_mi("abc - def", saat(12)))
        self.assertFalse(urfa.firin_acik_mi("25:00 - 26:00", saat(12)))


class TestMusteri(TestTabani):
    def test_ana_sayfa_sadece_onayli_firinlari_gosterir(self):
        self.firin_ekle("Onaylı Fırın", kullanici="a")
        self.firin_ekle("Bekleyen Fırın", durum="Bekliyor", kullanici="b")
        self.firin_ekle("Reddedilen Fırın", durum="Reddedildi", kullanici="c")
        yanit = self.istemci.get("/")
        self.assertEqual(yanit.status_code, 200)
        govde = self.metin(yanit)
        self.assertIn("Onaylı Fırın", govde)
        self.assertNotIn("Bekleyen Fırın", govde)
        self.assertNotIn("Reddedilen Fırın", govde)

    def test_firin_sayfasi_acik(self):
        firin_id = self.firin_ekle()
        govde = self.metin(self.istemci.get(f"/firin/{firin_id}"))
        self.assertIn("Tırnaklı Ekmek", govde)
        self.assertIn("Lavaş", govde)
        self.assertIn("15 TL", govde)
        self.assertIn("Sepete Ekle", govde)
        self.assertNotIn("Fırın Kapalı", govde)

    def test_firin_sayfasi_kapali(self):
        firin_id = self.firin_ekle(saatler="06:00 - 11:00")
        govde = self.metin(self.istemci.get(f"/firin/{firin_id}"))
        self.assertIn("Fırın Kapalı", govde)
        self.assertNotIn("Sepete Ekle", govde)

    def test_gecersiz_firin(self):
        yanit = self.istemci.get("/firin/999", follow_redirects=True)
        self.assertEqual(yanit.status_code, 200)
        self.assertIn("bulunamadı", self.metin(yanit))

    def test_bekleyen_firin_sayfasi_acilmaz(self):
        firin_id = self.firin_ekle(durum="Bekliyor")
        yanit = self.istemci.get(f"/firin/{firin_id}", follow_redirects=True)
        self.assertIn("bulunamadı", self.metin(yanit))

    def test_sepet_adet_ve_toplam(self):
        firin_id = self.firin_ekle()
        self.sepete_ekle(self.istemci, firin_id, 1)
        govde = self.metin(self.istemci.get("/sepet"))
        self.assertIn("Tırnaklı Ekmek", govde)
        self.assertIn("<td>1</td>", govde)

        # Aynı ürün tekrar: adet 2 olmalı
        self.sepete_ekle(self.istemci, firin_id, 1)
        govde = self.metin(self.istemci.get("/sepet"))
        self.assertIn("<td>2</td>", govde)

        # Lavaş ekle: Tırnaklı 2, Lavaş 1
        self.sepete_ekle(self.istemci, firin_id, 2)
        govde = self.metin(self.istemci.get("/sepet"))
        self.assertIn("Lavaş", govde)
        self.assertIn("<td>1</td>", govde)
        self.assertIn("<td>2</td>", govde)

        # 3 ürün x 15 = 45, kurye 30, genel 75
        self.assertIn("45 TL", govde)
        self.assertIn("30 TL", govde)
        self.assertIn("75 TL", govde)

    def test_sepet_ozeti_degerleri(self):
        firin_id = self.firin_ekle()
        self.sepete_ekle(self.istemci, firin_id, 1)
        govde = self.metin(self.istemci.get("/sepet"))
        # 1 tane Tırnaklı: 15 + 30 = 45
        self.assertIn("15 TL", govde)
        self.assertIn("45 TL", govde)

    def test_bos_sepet(self):
        govde = self.metin(self.istemci.get("/sepet"))
        self.assertIn("Sepetiniz boş", govde)
        self.assertNotIn("Sipariş Ver", govde)

    def test_baska_firindan_urun_eklenemez(self):
        firin_a = self.firin_ekle("Fırın A", kullanici="a")
        firin_b = self.firin_ekle("Fırın B", kullanici="b")
        self.sepete_ekle(self.istemci, firin_a, 1)
        yanit = self.sepete_ekle(self.istemci, firin_b, 2)
        self.assertIn("Sepetinizde başka bir fırından ürün var", self.metin(yanit))
        # Sepette hâlâ sadece A'nın ürünü var
        govde = self.metin(self.istemci.get("/sepet"))
        self.assertIn("Fırın A", govde)
        self.assertNotIn("Lavaş", govde)

    def test_sepet_temizle(self):
        firin_id = self.firin_ekle()
        self.sepete_ekle(self.istemci, firin_id, 1)
        self.istemci.get("/sepet-temizle")
        self.assertIn("Sepetiniz boş", self.metin(self.istemci.get("/sepet")))
        # Temizledikten sonra başka fırından ürün eklenebilir
        firin_b = self.firin_ekle("Fırın B", kullanici="b")
        self.sepete_ekle(self.istemci, firin_b, 2)
        self.assertIn("Fırın B", self.metin(self.istemci.get("/sepet")))

    def test_kapali_firina_urun_eklenemez(self):
        firin_id = self.firin_ekle(saatler="06:00 - 11:00")  # saat 12:00 -> kapalı
        yanit = self.sepete_ekle(self.istemci, firin_id, 1)
        self.assertIn("kapalı", self.metin(yanit))
        self.assertIn("Sepetiniz boş", self.metin(self.istemci.get("/sepet")))

    def test_elle_url_ile_ekleme_yapilamaz(self):
        firin_id = self.firin_ekle()
        # GET ile eklenmez
        self.istemci.get(f"/sepete-ekle/1?firin_id={firin_id}")
        self.assertIn("Sepetiniz boş", self.metin(self.istemci.get("/sepet")))

    def test_gecersiz_urun_ve_firin(self):
        firin_id = self.firin_ekle()
        yanit = self.sepete_ekle(self.istemci, firin_id, 99)
        self.assertIn("Geçersiz ürün", self.metin(yanit))
        yanit = self.istemci.post("/sepete-ekle/1", data={"firin_id": "abc"}, follow_redirects=True)
        self.assertIn("bulunamadı", self.metin(yanit))
        yanit = self.istemci.post("/sepete-ekle/1", data={}, follow_redirects=True)
        self.assertIn("bulunamadı", self.metin(yanit))
        self.assertIn("Sepetiniz boş", self.metin(self.istemci.get("/sepet")))

    def test_eski_bozuk_sepet_verisi_cokertmez(self):
        firin_id = self.firin_ekle()
        for bozuk in ([], {"1": 2}, "abc", {"firin_id": "x", "urunler": []}, {"firin_id": firin_id, "urunler": [1, 2]}):
            with self.istemci.session_transaction() as oturum:
                oturum["sepet"] = bozuk
            yanit = self.istemci.get("/sepet")
            self.assertEqual(yanit.status_code, 200)
            self.assertIn("Sepetiniz boş", self.metin(yanit))
        # Bozuk sepetten sonra normal ekleme çalışır
        self.sepete_ekle(self.istemci, firin_id, 1)
        self.assertIn("Tırnaklı Ekmek", self.metin(self.istemci.get("/sepet")))

    def test_sepetteki_firin_reddedilirse_sepet_temizlenir(self):
        firin_id = self.firin_ekle()
        self.sepete_ekle(self.istemci, firin_id, 1)
        self.calistir("UPDATE firin_basvurulari SET durum = 'Reddedildi' WHERE id = ?", (firin_id,))
        yanit = self.istemci.get("/sepet")
        self.assertEqual(yanit.status_code, 200)
        self.assertIn("Sepetiniz boş", self.metin(yanit))

    def test_siparis_olusturma(self):
        firin_id = self.firin_ekle()
        self.sepete_ekle(self.istemci, firin_id, 1)
        self.sepete_ekle(self.istemci, firin_id, 1)
        self.sepete_ekle(self.istemci, firin_id, 2)

        # Eksik alan
        yanit = self.istemci.post("/siparis-ver", data={"ad_soyad": "Ali", "telefon": "", "adres": "Adres"})
        self.assertIn("Lütfen tüm bilgileri doldurun.", self.metin(yanit))
        self.assertEqual(len(self.sorgu("SELECT id FROM siparisler")), 0)

        # Tam form
        yanit = self.istemci.post(
            "/siparis-ver",
            data={"ad_soyad": "Ali Veli", "telefon": "05551112233", "adres": "Örnek Mah. 1"},
        )
        self.assertEqual(yanit.status_code, 302)
        self.assertIn("/siparis-takip/", yanit.headers["Location"])

        siparisler = self.sorgu("SELECT * FROM siparisler")
        self.assertEqual(len(siparisler), 1)
        s = siparisler[0]
        self.assertEqual(s["durum"], "Bekliyor")
        self.assertEqual(s["firin_id"], firin_id)
        self.assertIsNone(s["kurye_id"])
        self.assertEqual(s["urun_toplami"], 45)
        self.assertEqual(s["kurye_ucreti"], 30)
        self.assertEqual(s["genel_toplam"], 75)
        self.assertIn("2 x Tırnaklı Ekmek", s["urunler"])
        self.assertIn("1 x Lavaş", s["urunler"])

        # Sepet temizlenmiş olmalı
        self.assertIn("Sepetiniz boş", self.metin(self.istemci.get("/sepet")))

        # Takip sayfası kişisel bilgi göstermez
        govde = self.metin(self.istemci.get(f"/siparis-takip/{s['id']}"))
        self.assertIn(f"Sipariş #{s['id']}", govde)
        self.assertIn("Bekliyor", govde)
        self.assertNotIn("Ali Veli", govde)
        self.assertNotIn("05551112233", govde)

        api = self.istemci.get(f"/api/siparis-durum/{s['id']}")
        self.assertEqual(api.get_json(), {"durum": "Bekliyor"})

    def test_bos_sepetle_siparis_verilemez(self):
        yanit = self.istemci.post(
            "/siparis-ver", data={"ad_soyad": "A", "telefon": "1", "adres": "B"}, follow_redirects=True
        )
        self.assertIn("Sepetiniz boş", self.metin(yanit))
        self.assertEqual(len(self.sorgu("SELECT id FROM siparisler")), 0)

    def test_firin_kapaninca_siparis_verilemez(self):
        firin_id = self.firin_ekle(saatler="06:00 - 20:00")
        self.sepete_ekle(self.istemci, firin_id, 1)
        with patch.object(urfa, "simdi_turkiye", return_value=saat(23)):
            yanit = self.istemci.post(
                "/siparis-ver", data={"ad_soyad": "A", "telefon": "1", "adres": "B"}
            )
        self.assertEqual(yanit.status_code, 200)
        self.assertIn("kapalı", self.metin(yanit))
        self.assertEqual(len(self.sorgu("SELECT id FROM siparisler")), 0)

    def test_gecersiz_siparis_takip(self):
        yanit = self.istemci.get("/siparis-takip/12345", follow_redirects=True)
        self.assertIn("Sipariş bulunamadı", self.metin(yanit))
        self.assertEqual(self.istemci.get("/api/siparis-durum/12345").status_code, 404)


class TestBasvurular(TestTabani):
    def firin_formu(self, **degisiklik):
        veri = {
            "firin_adi": "Yeni Fırın",
            "yetkili": "Ahmet",
            "telefon": "05551234567",
            "adres": "Balıklıgöl yanı",
            "acilis": "06:00",
            "kapanis": "20:00",
            "bolgeler": "Haliliye",
            "kullanici_adi": "yenifirin",
            "sifre": "gizli123",
        }
        veri.update(degisiklik)
        return veri

    def test_firin_basvurusu_kaydedilir(self):
        yanit = self.istemci.post("/firinci", data=self.firin_formu())
        self.assertEqual(yanit.status_code, 302)
        kayit = self.sorgu("SELECT * FROM firin_basvurulari")[0]
        self.assertEqual(kayit["durum"], "Bekliyor")
        self.assertEqual(kayit["saatler"], "06:00 - 20:00")
        self.assertNotEqual(kayit["sifre"], "gizli123")  # hash'lenmiş
        self.assertTrue(kayit["sifre"].startswith(("scrypt:", "pbkdf2:")))

    def test_firin_basvurusu_dogrulama(self):
        yanit = self.istemci.post("/firinci", data=self.firin_formu(sifre="123"))
        self.assertIn("en az 6 karakter", self.metin(yanit))
        yanit = self.istemci.post("/firinci", data=self.firin_formu(firin_adi=""))
        self.assertIn("Lütfen tüm alanları doldurun", self.metin(yanit))
        yanit = self.istemci.post("/firinci", data=self.firin_formu(acilis="25:99"))
        self.assertIn("saatini doğru girin", self.metin(yanit))
        yanit = self.istemci.post("/firinci", data=self.firin_formu(acilis="08:00", kapanis="08:00"))
        self.assertIn("aynı olamaz", self.metin(yanit))
        self.assertEqual(len(self.sorgu("SELECT id FROM firin_basvurulari")), 0)

    def test_saat_farkli_yazimlarla_kabul_edilir(self):
        yanit = self.istemci.post("/firinci", data=self.firin_formu(acilis="6:00", kapanis="20.30"))
        self.assertEqual(yanit.status_code, 302)
        self.assertEqual(self.sorgu("SELECT saatler FROM firin_basvurulari")[0]["saatler"], "06:00 - 20:30")

    def test_ayni_kullanici_adi_reddedilir(self):
        self.istemci.post("/firinci", data=self.firin_formu())
        yanit = self.istemci.post("/firinci", data=self.firin_formu(kullanici_adi="YENIFIRIN"))
        self.assertIn("zaten kullanılıyor", self.metin(yanit))
        self.assertEqual(len(self.sorgu("SELECT id FROM firin_basvurulari")), 1)

    def kurye_formu(self, **degisiklik):
        veri = {
            "ad_soyad": "Mehmet Kurye",
            "telefon": "05550000000",
            "yas": "22",
            "ilce": "Haliliye",
            "arac": "Motosiklet",
            "kullanici_adi": "mehmet",
            "sifre": "gizli123",
        }
        veri.update(degisiklik)
        return veri

    def test_kurye_basvurusu(self):
        yanit = self.istemci.post("/kurye", data=self.kurye_formu())
        self.assertEqual(yanit.status_code, 302)
        kayit = self.sorgu("SELECT * FROM kurye_basvurulari")[0]
        self.assertEqual(kayit["durum"], "Bekliyor")
        self.assertEqual(kayit["yas"], 22)
        self.assertNotEqual(kayit["sifre"], "gizli123")

    def test_kurye_yas_siniri(self):
        yanit = self.istemci.post("/kurye", data=self.kurye_formu(yas="17"))
        self.assertIn("18 yaşında", self.metin(yanit))
        yanit = self.istemci.post("/kurye", data=self.kurye_formu(yas="abc"))
        self.assertIn("rakamla", self.metin(yanit))
        yanit = self.istemci.post("/kurye", data=self.kurye_formu(sifre="12345"))
        self.assertIn("en az 6 karakter", self.metin(yanit))
        yanit = self.istemci.post("/kurye", data=self.kurye_formu(arac="Uçak"))
        self.assertIn("araç seçin", self.metin(yanit))
        self.assertEqual(len(self.sorgu("SELECT id FROM kurye_basvurulari")), 0)


class TestGirisler(TestTabani):
    def test_firinci_giris(self):
        self.firin_ekle()
        istemci = self.firinci_giris()
        yanit = istemci.get("/firinci-panel")
        self.assertEqual(yanit.status_code, 200)
        self.assertIn("Test Fırın", self.metin(yanit))

    def test_firinci_yanlis_sifre(self):
        self.firin_ekle()
        yanit = self.istemci.post("/firinci-giris", data={"kullanici_adi": "firin1", "sifre": "yanlis"})
        self.assertEqual(yanit.status_code, 200)
        self.assertIn("hatalı", self.metin(yanit))

    def test_onaysiz_firinci_giris_yapamaz(self):
        self.firin_ekle(durum="Bekliyor")
        yanit = self.istemci.post("/firinci-giris", data={"kullanici_adi": "firin1", "sifre": SIFRE})
        self.assertEqual(yanit.status_code, 200)
        self.assertIn("henüz onaylanmadı", self.metin(yanit))
        self.assertEqual(self.istemci.get("/firinci-panel").status_code, 302)

    def test_kurye_giris(self):
        self.kurye_ekle()
        istemci = self.kurye_giris()
        self.assertEqual(istemci.get("/kurye-panel").status_code, 200)

    def test_onaysiz_kurye_giris_yapamaz(self):
        self.kurye_ekle(durum="Bekliyor")
        yanit = self.istemci.post("/kurye-giris", data={"kullanici_adi": "kurye1", "sifre": SIFRE})
        self.assertIn("henüz onaylanmadı", self.metin(yanit))

    def test_admin_giris(self):
        yanit = self.istemci.post("/admin", data={"kullanici_adi": "admin", "sifre": "yanlis"})
        self.assertEqual(yanit.status_code, 200)
        self.assertIn("hatalı", self.metin(yanit))
        istemci = self.admin_giris()
        self.assertEqual(istemci.get("/admin-paneli").status_code, 200)

    def test_admin_bilgileri_ortam_degiskeninden_okunur(self):
        with patch.dict(os.environ, {"ADMIN_KULLANICI": "patron", "ADMIN_SIFRE": "cok-gizli"}):
            yanit = self.istemci.post("/admin", data={"kullanici_adi": "admin", "sifre": "1234"})
            self.assertEqual(yanit.status_code, 200)
            yanit = self.istemci.post("/admin", data={"kullanici_adi": "patron", "sifre": "cok-gizli"})
            self.assertEqual(yanit.status_code, 302)

    def test_eski_duz_metin_sifre_girisi_hashe_cevrilir(self):
        self.calistir(
            "INSERT INTO firin_basvurulari (firin_adi, yetkili, telefon, adres, saatler, bolgeler, "
            "kullanici_adi, sifre, durum) VALUES ('Eski', 'Y', '1', 'A', '06:00 - 20:00', 'B', 'eski', 'duzmetin', 'Onaylandı')"
        )
        yanit = self.istemci.post("/firinci-giris", data={"kullanici_adi": "eski", "sifre": "duzmetin"})
        self.assertEqual(yanit.status_code, 302)
        sifre = self.sorgu("SELECT sifre FROM firin_basvurulari")[0]["sifre"]
        self.assertTrue(sifre.startswith(("scrypt:", "pbkdf2:")))

    def test_giris_yapilmadan_paneller_ve_apiler_kapali(self):
        for adres in ("/firinci-panel", "/kurye-panel", "/admin-paneli"):
            yanit = self.istemci.get(adres)
            self.assertEqual(yanit.status_code, 302, adres)
        for adres in ("/api/firin-siparisleri", "/api/kurye-siparisleri"):
            yanit = self.istemci.get(adres)
            self.assertEqual(yanit.status_code, 401, adres)
        for adres in ("/firinci-durum/1", "/kurye-al/1", "/kurye-durum/1", "/admin/firin/1/onayla", "/admin/kurye/1/onayla"):
            yanit = self.istemci.post(adres, data={"durum": "Hazır"})
            self.assertEqual(yanit.status_code, 302, adres)

    def test_musteri_diger_rollerin_apisine_erisemez(self):
        # Sadece fırıncı girişi olan biri kurye/admin alanına giremez ve tersi
        self.firin_ekle()
        self.kurye_ekle()
        firinci = self.firinci_giris()
        self.assertEqual(firinci.get("/api/kurye-siparisleri").status_code, 401)
        self.assertEqual(firinci.get("/admin-paneli").status_code, 302)
        kurye = self.kurye_giris()
        self.assertEqual(kurye.get("/api/firin-siparisleri").status_code, 401)
        self.assertEqual(kurye.get("/admin-paneli").status_code, 302)

    def test_kaldirilan_firinci_aninda_dista_kalir(self):
        firin_id = self.firin_ekle()
        istemci = self.firinci_giris()
        self.assertEqual(istemci.get("/firinci-panel").status_code, 200)
        self.calistir("UPDATE firin_basvurulari SET durum = 'Reddedildi' WHERE id = ?", (firin_id,))
        self.assertEqual(istemci.get("/firinci-panel").status_code, 302)
        self.assertEqual(istemci.get("/api/firin-siparisleri").status_code, 401)

    def test_bozuk_session_cokertmez(self):
        with self.istemci.session_transaction() as oturum:
            oturum["firin_id"] = "abc"
            oturum["kurye_id"] = [1]
            oturum["admin"] = "evet"
        self.assertEqual(self.istemci.get("/firinci-panel").status_code, 302)
        self.assertEqual(self.istemci.get("/kurye-panel").status_code, 302)
        self.assertEqual(self.istemci.get("/admin-paneli").status_code, 302)


class TestFirinciYetkisi(TestTabani):
    def test_firinci_sadece_kendi_siparislerini_gorur(self):
        firin_a = self.firin_ekle("Fırın A", kullanici="firin1")
        firin_b = self.firin_ekle("Fırın B", kullanici="firin2")
        siparis_a = self.siparis_ekle(firin_a)
        siparis_b = self.siparis_ekle(firin_b)
        istemci = self.firinci_giris("firin1")
        veri = istemci.get("/api/firin-siparisleri").get_json()
        idler = [s["id"] for s in veri["siparisler"]]
        self.assertEqual(idler, [siparis_a])
        self.assertNotIn(siparis_b, idler)
        # Müşterinin telefonu/adresi fırıncıya gönderilmez
        self.assertNotIn("telefon", veri["siparisler"][0])
        self.assertNotIn("adres", veri["siparisler"][0])

    def test_durum_akisi_ve_yetki(self):
        firin_a = self.firin_ekle("Fırın A", kullanici="firin1")
        firin_b = self.firin_ekle("Fırın B", kullanici="firin2")
        siparis_a = self.siparis_ekle(firin_a)
        siparis_b = self.siparis_ekle(firin_b)
        istemci = self.firinci_giris("firin1")

        # Bekliyor -> Hazır atlanamaz
        istemci.post(f"/firinci-durum/{siparis_a}", data={"durum": "Hazır"})
        self.assertEqual(self.sorgu("SELECT durum FROM siparisler WHERE id = ?", (siparis_a,))[0]["durum"], "Bekliyor")

        istemci.post(f"/firinci-durum/{siparis_a}", data={"durum": "Hazırlanıyor"})
        self.assertEqual(self.sorgu("SELECT durum FROM siparisler WHERE id = ?", (siparis_a,))[0]["durum"], "Hazırlanıyor")
        istemci.post(f"/firinci-durum/{siparis_a}", data={"durum": "Hazır"})
        self.assertEqual(self.sorgu("SELECT durum FROM siparisler WHERE id = ?", (siparis_a,))[0]["durum"], "Hazır")

        # Fırıncı kurye durumlarını değiştiremez
        istemci.post(f"/firinci-durum/{siparis_a}", data={"durum": "Yolda"})
        istemci.post(f"/firinci-durum/{siparis_a}", data={"durum": "Teslim Edildi"})
        self.assertEqual(self.sorgu("SELECT durum FROM siparisler WHERE id = ?", (siparis_a,))[0]["durum"], "Hazır")

        # Başka fırının siparişine dokunamaz
        istemci.post(f"/firinci-durum/{siparis_b}", data={"durum": "Hazırlanıyor"})
        self.assertEqual(self.sorgu("SELECT durum FROM siparisler WHERE id = ?", (siparis_b,))[0]["durum"], "Bekliyor")


class TestKurye(TestTabani):
    def test_kurye_sadece_hazir_ve_sahipsiz_siparisleri_gorur(self):
        firin_id = self.firin_ekle()
        kurye1 = self.kurye_ekle("kurye1")
        kurye2 = self.kurye_ekle("kurye2")
        hazir = self.siparis_ekle(firin_id, "Hazır")
        self.siparis_ekle(firin_id, "Bekliyor")
        self.siparis_ekle(firin_id, "Hazırlanıyor")
        baskasinin = self.siparis_ekle(firin_id, "Yolda", kurye_id=kurye2)
        benim = self.siparis_ekle(firin_id, "Kurye Aldı", kurye_id=kurye1)

        veri = self.kurye_giris("kurye1").get("/api/kurye-siparisleri").get_json()
        self.assertEqual([s["id"] for s in veri["uygun_siparisler"]], [hazir])
        self.assertEqual([s["id"] for s in veri["benim_siparislerim"]], [benim])
        self.assertNotIn(baskasinin, [s["id"] for s in veri["benim_siparislerim"]])
        # Alınmamış siparişte müşteri adı/telefonu gösterilmez
        self.assertNotIn("telefon", veri["uygun_siparisler"][0])
        self.assertNotIn("ad_soyad", veri["uygun_siparisler"][0])

    def test_iki_kurye_ayni_siparisi_alamaz(self):
        firin_id = self.firin_ekle()
        kurye1 = self.kurye_ekle("kurye1")
        self.kurye_ekle("kurye2")
        siparis = self.siparis_ekle(firin_id, "Hazır")
        k1 = self.kurye_giris("kurye1")
        k2 = self.kurye_giris("kurye2")

        k1.post(f"/kurye-al/{siparis}")
        yanit = k2.post(f"/kurye-al/{siparis}", follow_redirects=True)
        self.assertIn("artık alınamaz", self.metin(yanit))
        satir = self.sorgu("SELECT durum, kurye_id FROM siparisler WHERE id = ?", (siparis,))[0]
        self.assertEqual(satir["durum"], "Kurye Aldı")
        self.assertEqual(satir["kurye_id"], kurye1)

    def test_hazir_olmayan_siparis_alinamaz(self):
        firin_id = self.firin_ekle()
        self.kurye_ekle("kurye1")
        siparis = self.siparis_ekle(firin_id, "Hazırlanıyor")
        self.kurye_giris("kurye1").post(f"/kurye-al/{siparis}")
        satir = self.sorgu("SELECT durum, kurye_id FROM siparisler WHERE id = ?", (siparis,))[0]
        self.assertEqual(satir["durum"], "Hazırlanıyor")
        self.assertIsNone(satir["kurye_id"])

    def test_durum_akisi_ve_baskasinin_siparisine_dokunamama(self):
        firin_id = self.firin_ekle()
        kurye1 = self.kurye_ekle("kurye1")
        self.kurye_ekle("kurye2")
        siparis = self.siparis_ekle(firin_id, "Kurye Aldı", kurye_id=kurye1)
        k1 = self.kurye_giris("kurye1")
        k2 = self.kurye_giris("kurye2")

        # Başka kurye değiştiremez
        k2.post(f"/kurye-durum/{siparis}", data={"durum": "Yolda"})
        self.assertEqual(self.sorgu("SELECT durum FROM siparisler WHERE id = ?", (siparis,))[0]["durum"], "Kurye Aldı")

        # Sıra atlanamaz
        k1.post(f"/kurye-durum/{siparis}", data={"durum": "Teslim Edildi"})
        self.assertEqual(self.sorgu("SELECT durum FROM siparisler WHERE id = ?", (siparis,))[0]["durum"], "Kurye Aldı")

        k1.post(f"/kurye-durum/{siparis}", data={"durum": "Yolda"})
        self.assertEqual(self.sorgu("SELECT durum FROM siparisler WHERE id = ?", (siparis,))[0]["durum"], "Yolda")
        k1.post(f"/kurye-durum/{siparis}", data={"durum": "Teslim Edildi"})
        self.assertEqual(self.sorgu("SELECT durum FROM siparisler WHERE id = ?", (siparis,))[0]["durum"], "Teslim Edildi")


class TestAdmin(TestTabani):
    def test_admin_onaylar_reddeder_kaldirir(self):
        firin_id = self.firin_ekle(durum="Bekliyor")
        kurye_id = self.kurye_ekle(durum="Bekliyor")
        admin = self.admin_giris()

        admin.post(f"/admin/firin/{firin_id}/onayla")
        self.assertEqual(self.sorgu("SELECT durum FROM firin_basvurulari")[0]["durum"], "Onaylandı")
        admin.post(f"/admin/firin/{firin_id}/reddet")  # onaylı fırını kaldırma
        self.assertEqual(self.sorgu("SELECT durum FROM firin_basvurulari")[0]["durum"], "Reddedildi")
        self.assertEqual(len(self.sorgu("SELECT id FROM firin_basvurulari")), 1)  # silinmez

        admin.post(f"/admin/kurye/{kurye_id}/onayla")
        self.assertEqual(self.sorgu("SELECT durum FROM kurye_basvurulari")[0]["durum"], "Onaylandı")

        admin.post(f"/admin/firin/{firin_id}/gecersiz")
        self.assertEqual(self.sorgu("SELECT durum FROM firin_basvurulari")[0]["durum"], "Reddedildi")

    def test_admin_paneli_her_seyi_listeler(self):
        firin_id = self.firin_ekle("Panel Fırını", durum="Bekliyor")
        self.kurye_ekle()
        self.siparis_ekle(firin_id)
        govde = self.metin(self.admin_giris().get("/admin-paneli"))
        self.assertIn("Panel Fırını", govde)
        self.assertIn("Kurye Kişi", govde)
        self.assertIn("Sipariş #1", govde)
        self.assertIn("Onayla", govde)
        self.assertNotIn("scrypt:", govde)  # şifre hash'i asla gösterilmez


class TestVeritabani(TestTabani):
    def test_eski_veritabanina_eksik_sutun_eklenir_veri_silinmez(self):
        import sqlite3

        yol = os.path.join(self.klasor.name, "eski.db")
        db = sqlite3.connect(yol)
        db.execute("CREATE TABLE firin_basvurulari (id INTEGER PRIMARY KEY AUTOINCREMENT, firin_adi TEXT)")
        db.execute("INSERT INTO firin_basvurulari (firin_adi) VALUES ('Eski Fırın')")
        db.commit()
        db.close()

        urfa.app.config["DATABASE"] = yol
        urfa.veritabani_hazirla()

        db = sqlite3.connect(yol)
        sutunlar = {satir[1] for satir in db.execute("PRAGMA table_info(firin_basvurulari)")}
        adlar = [satir[0] for satir in db.execute("SELECT firin_adi FROM firin_basvurulari")]
        tablolar = {satir[0] for satir in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        db.close()
        self.assertIn("saatler", sutunlar)
        self.assertIn("sifre", sutunlar)
        self.assertEqual(adlar, ["Eski Fırın"])
        self.assertIn("siparisler", tablolar)
        self.assertIn("kurye_basvurulari", tablolar)


class TestTamAkis(TestTabani):
    """Baştan sona: başvuru -> onay -> sipariş -> hazırlık -> kurye -> teslim."""

    def test_tam_akis(self):
        admin = self.admin_giris()

        # Fırın başvurusu + admin onayı
        self.istemci.post("/firinci", data={
            "firin_adi": "Akış Fırını", "yetkili": "Ali", "telefon": "0555", "adres": "Adres",
            "acilis": "06:00", "kapanis": "20:00", "bolgeler": "Haliliye",
            "kullanici_adi": "akisfirin", "sifre": "gizli123",
        })
        firin_id = self.sorgu("SELECT id FROM firin_basvurulari")[0]["id"]
        self.assertNotIn("Akış Fırını", self.metin(self.istemci.get("/")))  # henüz onaysız
        admin.post(f"/admin/firin/{firin_id}/onayla")
        self.assertIn("Akış Fırını", self.metin(self.istemci.get("/")))

        # Müşteri sepeti ve siparişi
        self.sepete_ekle(self.istemci, firin_id, 1)
        self.sepete_ekle(self.istemci, firin_id, 1)
        self.sepete_ekle(self.istemci, firin_id, 2)
        yanit = self.istemci.post(
            "/siparis-ver", data={"ad_soyad": "Zeynep", "telefon": "0532", "adres": "Yeni Mah."}
        )
        siparis_id = int(yanit.headers["Location"].rstrip("/").split("/")[-1])
        durum = lambda: self.istemci.get(f"/api/siparis-durum/{siparis_id}").get_json()["durum"]  # noqa: E731
        self.assertEqual(durum(), "Bekliyor")

        # Fırıncı
        firinci = urfa.app.test_client()
        firinci.post("/firinci-giris", data={"kullanici_adi": "akisfirin", "sifre": "gizli123"})
        self.assertEqual(len(firinci.get("/api/firin-siparisleri").get_json()["siparisler"]), 1)
        firinci.post(f"/firinci-durum/{siparis_id}", data={"durum": "Hazırlanıyor"})
        self.assertEqual(durum(), "Hazırlanıyor")
        firinci.post(f"/firinci-durum/{siparis_id}", data={"durum": "Hazır"})
        self.assertEqual(durum(), "Hazır")

        # Kurye başvurusu + admin onayı + giriş
        self.istemci.post("/kurye", data={
            "ad_soyad": "Kadir", "telefon": "0544", "yas": "30", "ilce": "Haliliye",
            "arac": "Motosiklet", "kullanici_adi": "kadir", "sifre": "gizli123",
        })
        kurye_id = self.sorgu("SELECT id FROM kurye_basvurulari")[0]["id"]
        admin.post(f"/admin/kurye/{kurye_id}/onayla")
        kurye = urfa.app.test_client()
        kurye.post("/kurye-giris", data={"kullanici_adi": "kadir", "sifre": "gizli123"})
        veri = kurye.get("/api/kurye-siparisleri").get_json()
        self.assertEqual([s["id"] for s in veri["uygun_siparisler"]], [siparis_id])

        kurye.post(f"/kurye-al/{siparis_id}")
        self.assertEqual(durum(), "Kurye Aldı")
        kurye.post(f"/kurye-durum/{siparis_id}", data={"durum": "Yolda"})
        self.assertEqual(durum(), "Yolda")
        kurye.post(f"/kurye-durum/{siparis_id}", data={"durum": "Teslim Edildi"})
        self.assertEqual(durum(), "Teslim Edildi")

        # Müşteri takip sayfası son durumu gösterir
        self.assertIn("Teslim Edildi", self.metin(self.istemci.get(f"/siparis-takip/{siparis_id}")))


if __name__ == "__main__":
    unittest.main()
