# UrfaEkmek

Şanlıurfa'da müşterilerin fırınlardan ekmek sipariş ettiği, fırınların siparişleri hazırladığı ve kuryelerin teslim ettiği web uygulaması.
Teknoloji: **Python + Flask + SQLite** (ödeme sistemi yok, ücretli servis yok).

## 1. Python kurulumu (Windows)

1. https://www.python.org/downloads/ adresinden Python 3.10 veya daha yenisini indirin.
2. Kurulumda **"Add Python to PATH"** kutusunu işaretleyin.
3. VS Code'da `Terminal > New Terminal` ile terminal açıp `python --version` yazarak kontrol edin.

## 2. Sanal ortam (bir kez yapılır)

```
cd UrfaEkmek
python -m venv venv
venv\Scripts\activate
```

Terminalde satırın başında `(venv)` görünmelidir. PowerShell "script çalıştırılamıyor" derse bir kez şunu çalıştırın:
`Set-ExecutionPolicy -Scope CurrentUser RemoteSigned`

## 3. Paketleri kurma

```
pip install -r requirements.txt
```

## 4. Çalıştırma

```
python app.py
```

## 5. Tarayıcıdan açma

http://127.0.0.1:5000

İlk çalıştırmada `urfaekmek.db` dosyası otomatik oluşur. Elinizde eski bir `urfaekmek.db` varsa proje klasörüne koyun: veriler silinmez, eksik tablolar/sütunlar otomatik eklenir.

## 6. Admin girişi

- Adres: http://127.0.0.1:5000/admin
- Kullanıcı adı: `admin`
- Şifre: `1234`

**Canlıya çıkmadan önce mutlaka değiştirin** (aşağıya bakın).

### İlk denemede izlenecek sıra

1. `/firinci` sayfasından fırın başvurusu yapın.
2. `/admin` ile girip fırını **Onayla**.
3. Ana sayfada fırın görünür; ürün ekleyip sipariş verin.
4. `/firinci-giris` ile girip siparişi **İşleme Al**, sonra **Hazır** yapın.
5. `/kurye` ile kurye başvurusu yapın, admin onaylasın.
6. `/kurye-giris` ile girip **Siparişi Al**, **Yola Çıktım**, **Teslim Ettim**.

## Sayfalar

| Adres | Ne işe yarar |
|---|---|
| `/` | Onaylı fırınlar |
| `/firin/<id>` | Fırının ürünleri |
| `/sepet` | Sepet |
| `/siparis-ver` | Sipariş formu |
| `/siparis-takip/<id>` | Sipariş takibi (5 saniyede bir kendini günceller) |
| `/firinci`, `/firinci-giris`, `/firinci-panel` | Fırıncı başvuru, giriş, panel |
| `/kurye`, `/kurye-giris`, `/kurye-panel` | Kurye başvuru, giriş, panel |
| `/admin`, `/admin-paneli` | Admin giriş ve panel |

## Testler

```
python -m unittest discover -s tests -v
```

`pytest` ile çalıştırmak isterseniz: `pip install -r requirements-dev.txt` ardından `pytest`.

## 7. Render'a yükleme

1. Projeyi GitHub'a yükleyin.
2. Render'da **New > Web Service** ile depoyu seçin.
3. Ayarlar:
   - Build Command: `pip install -r requirements.txt`
   - Start Command: `gunicorn app:app`
4. **Environment** bölümüne şunları ekleyin:
   - `SECRET_KEY` = uzun, rastgele bir metin
   - `ADMIN_KULLANICI` = kendi admin kullanıcı adınız
   - `ADMIN_SIFRE` = güçlü bir şifre

## 8. Bilinen sınırlamalar

- **SQLite ve Render Free:** Render'ın ücretsiz planında dosya sistemi kalıcı değildir. Uygulama yeniden başladığında veya yeniden yayınlandığında `urfaekmek.db` sıfırlanabilir. Test için yeterlidir; gerçek kullanımda kalıcı disk (ücretli) veya PostgreSQL gerekir.
- Ürünler ve fiyatlar `app.py` içindeki `URUNLER` sözlüğünde sabittir.
- Sepet, tarayıcının çerezinde (session) tutulur. Çerezler silinirse sepet de silinir.
- Sipariş takip sayfası, sipariş numarasını bilen herkese açıktır; ancak ad, telefon ve adres gösterilmez.
- CSRF koruması ve giriş denemesi sınırı yoktur (ilk sürüm sadeliği için).
- Sipariş bildirimi (SMS, e-posta) yoktur; paneller 5 saniyede bir kendini yeniler.
