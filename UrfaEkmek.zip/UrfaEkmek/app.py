"""UrfaEkmek - Şanlıurfa ekmek sipariş ve teslimat uygulaması.

Flask + SQLite ile yazıldı. Dört kullanıcı grubu var:
müşteri, fırıncı, kurye ve admin.

Yerel çalıştırma:   python app.py   ->   http://127.0.0.1:5000
Render'da:          gunicorn app:app
"""

import hmac
import os
import sqlite3
from datetime import datetime, timedelta, timezone
from functools import wraps

from flask import (
    Flask,
    flash,
    g,
    jsonify,
    redirect,
    render_template,
    request,
    session,
    url_for,
)
from werkzeug.security import check_password_hash, generate_password_hash

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

app = Flask(__name__)
# Gizli anahtar ve veritabanı yolu ortam değişkeninden okunabilir (Render için).
app.secret_key = os.environ.get("SECRET_KEY", "yerel-gelistirme-anahtari-degistir")
app.config["DATABASE"] = os.environ.get(
    "URFAEKMEK_DB", os.path.join(BASE_DIR, "urfaekmek.db")
)
app.config["SESSION_COOKIE_SAMESITE"] = "Lax"


# ---------------------------------------------------------------------------
# SABİTLER
# ---------------------------------------------------------------------------

# Ürünler sistem tarafından sabittir. Fırıncı ürün ekleyemez / fiyat değiştiremez.
URUNLER = {
    1: {"id": 1, "ad": "Tırnaklı Ekmek", "fiyat": 15, "emoji": "🥖"},
    2: {"id": 2, "ad": "Lavaş", "fiyat": 15, "emoji": "🫓"},
}

KURYE_UCRETI = 30  # Sepet boş değilse eklenir.

# Sipariş durumlarının sırası (takip sayfasındaki ilerleme çubuğu için de kullanılır)
SIPARIS_DURUMLARI = [
    "Bekliyor",
    "Hazırlanıyor",
    "Hazır",
    "Kurye Aldı",
    "Yolda",
    "Teslim Edildi",
]

# CSS sınıfı için durum -> kısa ad
DURUM_SINIFI = {
    "Bekliyor": "bekliyor",
    "Hazırlanıyor": "hazirlaniyor",
    "Hazır": "hazir",
    "Kurye Aldı": "kurye-aldi",
    "Yolda": "yolda",
    "Teslim Edildi": "teslim",
}

# Fırıncının yapabileceği geçişler:  yeni durum -> gerekli eski durum
FIRIN_GECISLERI = {"Hazırlanıyor": "Bekliyor", "Hazır": "Hazırlanıyor"}

# Kuryenin yapabileceği geçişler:  yeni durum -> gerekli eski durum
KURYE_GECISLERI = {"Yolda": "Kurye Aldı", "Teslim Edildi": "Yolda"}

ARACLAR = ["Motosiklet", "Bisiklet", "Otomobil"]

# Türkiye UTC+3 (yaz/kış saati yok). Windows'ta saat dilimi veritabanı gerekmesin diye
# sabit bir fark kullanıyoruz.
TURKIYE_SAATI = timezone(timedelta(hours=3))


# ---------------------------------------------------------------------------
# VERİTABANI
# ---------------------------------------------------------------------------

# Her tablo için sütunlar. "id" sütunu otomatik eklenir.
# Eski bir urfaekmek.db varsa eksik sütunlar güvenle eklenir, veri silinmez.
TABLOLAR = {
    "firin_basvurulari": [
        ("firin_adi", "TEXT"),
        ("yetkili", "TEXT"),
        ("telefon", "TEXT"),
        ("adres", "TEXT"),
        ("saatler", "TEXT"),
        ("bolgeler", "TEXT"),
        ("kullanici_adi", "TEXT"),
        ("sifre", "TEXT"),
        ("durum", "TEXT"),
    ],
    "kurye_basvurulari": [
        ("ad_soyad", "TEXT"),
        ("telefon", "TEXT"),
        ("yas", "INTEGER"),
        ("ilce", "TEXT"),
        ("arac", "TEXT"),
        ("kullanici_adi", "TEXT"),
        ("sifre", "TEXT"),
        ("durum", "TEXT"),
    ],
    "siparisler": [
        ("ad_soyad", "TEXT"),
        ("telefon", "TEXT"),
        ("adres", "TEXT"),
        ("urunler", "TEXT"),
        ("urun_toplami", "REAL"),
        ("kurye_ucreti", "REAL"),
        ("genel_toplam", "REAL"),
        ("durum", "TEXT"),
        ("kurye_id", "INTEGER"),
        ("firin_id", "INTEGER"),
    ],
}


def veritabani_hazirla():
    """Tabloları oluşturur; eski veritabanında eksik sütun varsa ekler."""
    db = sqlite3.connect(app.config["DATABASE"])
    try:
        for tablo, sutunlar in TABLOLAR.items():
            sutun_sql = ", ".join(f"{ad} {tip}" for ad, tip in sutunlar)
            db.execute(
                f"CREATE TABLE IF NOT EXISTS {tablo} "
                f"(id INTEGER PRIMARY KEY AUTOINCREMENT, {sutun_sql})"
            )
            mevcut = {satir[1] for satir in db.execute(f"PRAGMA table_info({tablo})")}
            for ad, tip in sutunlar:
                if ad not in mevcut:
                    db.execute(f"ALTER TABLE {tablo} ADD COLUMN {ad} {tip}")
        db.commit()
    finally:
        db.close()


def get_db():
    """İstek başına tek bir veritabanı bağlantısı verir."""
    if "db" not in g:
        g.db = sqlite3.connect(app.config["DATABASE"])
        g.db.row_factory = sqlite3.Row
    return g.db


@app.teardown_appcontext
def veritabanini_kapat(hata=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


# ---------------------------------------------------------------------------
# YARDIMCI FONKSİYONLAR
# ---------------------------------------------------------------------------


def simdi_turkiye():
    """Türkiye saatiyle şu anki zaman. (Testlerde değiştirilebilsin diye ayrı fonksiyon.)"""
    return datetime.now(TURKIYE_SAATI)


def saat_coz(metin):
    """'06:30' -> gün başından itibaren dakika (390). Hatalıysa None."""
    try:
        # "6:00", "06.30" gibi yazımlar da kabul edilir.
        saat, dakika = metin.strip().replace(".", ":").split(":")
        saat, dakika = int(saat), int(dakika)
    except (ValueError, AttributeError):
        return None
    if 0 <= saat <= 23 and 0 <= dakika <= 59:
        return saat * 60 + dakika
    return None


def firin_acik_mi(saatler, simdi=None):
    """'06:00 - 20:00' gibi bir metne göre fırının açık olup olmadığını söyler.

    Gece çalışan fırınlar da desteklenir: '22:00 - 06:00'.
    """
    if simdi is None:
        simdi = simdi_turkiye()
    try:
        acilis_metni, kapanis_metni = saatler.split("-")
    except (ValueError, AttributeError):
        return False
    acilis = saat_coz(acilis_metni)
    kapanis = saat_coz(kapanis_metni)
    if acilis is None or kapanis is None or acilis == kapanis:
        return False
    su_an = simdi.hour * 60 + simdi.minute
    if acilis < kapanis:
        return acilis <= su_an < kapanis
    # Gece yarısını geçen vardiya
    return su_an >= acilis or su_an < kapanis


@app.template_filter("tl")
def tl_filtresi(deger):
    """45.0 -> '45 TL'"""
    try:
        sayi = float(deger)
    except (TypeError, ValueError):
        return "0 TL"
    if sayi == int(sayi):
        return f"{int(sayi)} TL"
    return f"{sayi:.2f}".replace(".", ",") + " TL"


app.jinja_env.globals["durum_sinifi"] = lambda durum: DURUM_SINIFI.get(durum, "bekliyor")
app.jinja_env.globals["admin_sinifi"] = lambda durum: {
    "Bekliyor": "bekliyor",
    "Onaylandı": "onayli",
    "Reddedildi": "red",
}.get(durum, "bekliyor")


def metin_al(alan, uzunluk=200):
    """Formdan gelen metni temizler ve çok uzunsa keser."""
    return (request.form.get(alan) or "").strip()[:uzunluk]


def sifre_dogru_mu(kayitli, girilen):
    """Şifreyi kontrol eder.

    Yeni kayıtlar hash'li tutulur. Eski (düz metin) bir veritabanı gelirse yine
    giriş yapılabilsin diye düz metin de kabul edilir ve girişte hash'e çevrilir.
    """
    if not kayitli:
        return False
    if kayitli.startswith(("scrypt:", "pbkdf2:")):
        return check_password_hash(kayitli, girilen)
    return hmac.compare_digest(kayitli.encode("utf-8"), girilen.encode("utf-8"))


def giris_dene(tablo, kullanici_adi, sifre):
    """Fırıncı/kurye girişi. (kayit, hata_mesaji) döndürür."""
    db = get_db()
    adaylar = db.execute(
        f"SELECT * FROM {tablo} WHERE lower(kullanici_adi) = lower(?)",
        (kullanici_adi,),
    ).fetchall()
    for kayit in adaylar:
        if not sifre_dogru_mu(kayit["sifre"], sifre):
            continue
        if kayit["durum"] == "Onaylandı":
            if not kayit["sifre"].startswith(("scrypt:", "pbkdf2:")):
                db.execute(
                    f"UPDATE {tablo} SET sifre = ? WHERE id = ?",
                    (generate_password_hash(sifre), kayit["id"]),
                )
                db.commit()
            return kayit, None
        if kayit["durum"] == "Reddedildi":
            return None, "Başvurunuz onaylanmadı. Yönetici ile iletişime geçin."
        return None, "Başvurunuz henüz onaylanmadı. Onaylandığında giriş yapabilirsiniz."
    return None, "Kullanıcı adı veya şifre hatalı."


def kullanici_adi_kullaniliyor_mu(tablo, kullanici_adi):
    satir = get_db().execute(
        f"SELECT id FROM {tablo} WHERE lower(kullanici_adi) = lower(?)",
        (kullanici_adi,),
    ).fetchone()
    return satir is not None


def onayli_firin_getir(firin_id):
    return get_db().execute(
        "SELECT * FROM firin_basvurulari WHERE id = ? AND durum = 'Onaylandı'",
        (firin_id,),
    ).fetchone()


# ---------------------------------------------------------------------------
# GİRİŞ KONTROLÜ (yetki)
# ---------------------------------------------------------------------------

GIRIS_SAYFALARI = {"firin": "firinci_giris", "kurye": "kurye_giris", "admin": "admin_giris"}


def oturum_kaydi(rol):
    """Giriş yapmış kullanıcının veritabanı kaydını verir. Yoksa None.

    Her istekte veritabanından kontrol edilir; yani admin bir fırını/kuryeyi
    kaldırırsa o kişi anında dışarıda kalır.
    """
    if rol == "admin":
        return True if session.get("admin") is True else None

    anahtar = "firin_id" if rol == "firin" else "kurye_id"
    tablo = "firin_basvurulari" if rol == "firin" else "kurye_basvurulari"
    kimlik = session.get(anahtar)
    if not isinstance(kimlik, int) or isinstance(kimlik, bool):
        session.pop(anahtar, None)
        return None
    kayit = get_db().execute(
        f"SELECT * FROM {tablo} WHERE id = ? AND durum = 'Onaylandı'", (kimlik,)
    ).fetchone()
    if kayit is None:
        session.pop(anahtar, None)
    return kayit


def giris_gerekli(rol, api=False):
    """Route'u sadece giriş yapmış fırıncı/kurye/admin için açar."""

    def dekorator(fonksiyon):
        @wraps(fonksiyon)
        def sarmal(*args, **kwargs):
            kayit = oturum_kaydi(rol)
            if kayit is None:
                if api:
                    return jsonify({"hata": "Giriş yapmalısınız."}), 401
                flash("Bu sayfa için giriş yapmalısınız.", "hata")
                return redirect(url_for(GIRIS_SAYFALARI[rol]))
            g.kullanici = kayit
            return fonksiyon(*args, **kwargs)

        return sarmal

    return dekorator


# ---------------------------------------------------------------------------
# SEPET
# ---------------------------------------------------------------------------
# Sepet TEK bir yapıda tutulur (session içinde):
#   {"firin_id": 3, "urunler": {"1": 2, "2": 1}}      (ürün id -> adet)
# Yapı bozuk veya eski ise sepeti_oku() sepeti sessizce sıfırlar.


def sepeti_oku():
    """(firin_id, {urun_id: adet}) döndürür. Sepet boşsa (None, {})."""
    ham = session.get("sepet")
    if not isinstance(ham, dict):
        session.pop("sepet", None)
        return None, {}
    firin_id = ham.get("firin_id")
    ham_urunler = ham.get("urunler")
    if (
        not isinstance(firin_id, int)
        or isinstance(firin_id, bool)
        or not isinstance(ham_urunler, dict)
    ):
        session.pop("sepet", None)
        return None, {}

    urunler = {}
    for anahtar, adet in ham_urunler.items():
        try:
            urun_id = int(anahtar)
        except (TypeError, ValueError):
            continue
        gecerli_adet = isinstance(adet, int) and not isinstance(adet, bool) and adet > 0
        if urun_id in URUNLER and gecerli_adet:
            urunler[urun_id] = adet
    if not urunler:
        session.pop("sepet", None)
        return None, {}
    return firin_id, urunler


def sepeti_kaydet(firin_id, urunler):
    session["sepet"] = {
        "firin_id": firin_id,
        "urunler": {str(urun_id): adet for urun_id, adet in urunler.items()},
    }


def sepet_ozeti():
    """Sepet sayfasının ve sipariş sayfasının ihtiyacı olan her şeyi hazırlar."""
    firin_id, urunler = sepeti_oku()
    firin = None
    if firin_id is not None:
        firin = onayli_firin_getir(firin_id)
        if firin is None:
            session.pop("sepet", None)
            urunler = {}
            flash("Sepetinizdeki fırın artık hizmet vermiyor. Sepetiniz temizlendi.", "hata")

    sepet_urunleri = []
    urun_toplami = 0
    for urun_id in sorted(urunler):
        urun = URUNLER[urun_id]
        ara_toplam = urun["fiyat"] * urunler[urun_id]
        sepet_urunleri.append(
            {"urun": urun, "adet": urunler[urun_id], "ara_toplam": ara_toplam}
        )
        urun_toplami += ara_toplam

    kurye_ucreti = KURYE_UCRETI if sepet_urunleri else 0
    return {
        "firin": firin,
        "firin_acik": bool(firin) and firin_acik_mi(firin["saatler"]),
        "sepet_urunleri": sepet_urunleri,
        "urun_toplami": urun_toplami,
        "kurye_ucreti": kurye_ucreti,
        "genel_toplam": urun_toplami + kurye_ucreti,
    }


@app.context_processor
def ortak_degiskenler():
    """Her şablonda kullanılabilen değişkenler."""
    _, urunler = sepeti_oku()
    return {"sepet_adedi": sum(urunler.values())}


# ---------------------------------------------------------------------------
# MÜŞTERİ SAYFALARI
# ---------------------------------------------------------------------------


@app.route("/")
def anasayfa():
    satirlar = get_db().execute(
        "SELECT * FROM firin_basvurulari WHERE durum = 'Onaylandı' ORDER BY firin_adi"
    ).fetchall()
    firinlar = [{"kayit": f, "acik": firin_acik_mi(f["saatler"])} for f in satirlar]
    return render_template("index.html", firinlar=firinlar)


@app.route("/firin/<int:firin_id>")
def firin_sayfasi(firin_id):
    firin = onayli_firin_getir(firin_id)
    if firin is None:
        flash("Bu fırın bulunamadı veya şu anda hizmet vermiyor.", "hata")
        return redirect(url_for("anasayfa"))
    sepet_firin_id, _ = sepeti_oku()
    return render_template(
        "firin.html",
        firin=firin,
        acik=firin_acik_mi(firin["saatler"]),
        urunler=list(URUNLER.values()),
        baska_firinda_sepet=sepet_firin_id is not None and sepet_firin_id != firin_id,
    )


@app.route("/sepete-ekle/<int:urun_id>", methods=["GET", "POST"])
def sepete_ekle(urun_id):
    if request.method == "GET":
        # Adres çubuğundan elle çağrılırsa hiçbir şey eklenmez.
        flash("Ürünleri fırın sayfasındaki 'Sepete Ekle' düğmesiyle ekleyebilirsiniz.", "bilgi")
        return redirect(url_for("anasayfa"))

    if urun_id not in URUNLER:
        flash("Geçersiz ürün.", "hata")
        return redirect(url_for("anasayfa"))

    firin_id = request.form.get("firin_id", type=int)
    firin = onayli_firin_getir(firin_id) if firin_id is not None else None
    if firin is None:
        flash("Bu fırın bulunamadı veya şu anda hizmet vermiyor.", "hata")
        return redirect(url_for("anasayfa"))

    # Kapalı fırın kontrolü BACKEND'de de yapılır.
    if not firin_acik_mi(firin["saatler"]):
        flash("🔴 Fırın şu anda kapalı. Çalışma saatleri içinde tekrar deneyin.", "hata")
        return redirect(url_for("firin_sayfasi", firin_id=firin_id))

    sepet_firin_id, urunler = sepeti_oku()
    if sepet_firin_id is not None and sepet_firin_id != firin_id:
        flash("Sepetinizde başka bir fırından ürün var. Önce sepetinizi temizleyin.", "hata")
        return redirect(url_for("firin_sayfasi", firin_id=firin_id))

    urunler[urun_id] = urunler.get(urun_id, 0) + 1
    sepeti_kaydet(firin_id, urunler)
    flash(f"{URUNLER[urun_id]['ad']} sepete eklendi.", "basari")
    return redirect(url_for("firin_sayfasi", firin_id=firin_id))


@app.route("/sepet")
def sepet():
    return render_template("sepet.html", **sepet_ozeti())


@app.route("/sepet-temizle", methods=["GET", "POST"])
def sepet_temizle():
    session.pop("sepet", None)
    flash("Sepetiniz temizlendi.", "bilgi")
    firin_id = request.values.get("firin", type=int)
    if firin_id is not None:
        return redirect(url_for("firin_sayfasi", firin_id=firin_id))
    return redirect(url_for("sepet"))


@app.route("/siparis-ver", methods=["GET", "POST"])
def siparis_ver():
    ozet = sepet_ozeti()
    if not ozet["sepet_urunleri"]:
        flash("Sepetiniz boş. Önce bir fırından ürün ekleyin.", "hata")
        return redirect(url_for("sepet"))

    if request.method == "GET":
        return render_template("siparis_ver.html", form={}, **ozet)

    form = {
        "ad_soyad": metin_al("ad_soyad", 100),
        "telefon": metin_al("telefon", 30),
        "adres": metin_al("adres", 500),
    }
    if not all(form.values()):
        flash("Lütfen tüm bilgileri doldurun.", "hata")
        return render_template("siparis_ver.html", form=form, **ozet)

    if not ozet["firin_acik"]:
        flash("🔴 Fırın şu anda kapalı. Sipariş verilemiyor.", "hata")
        return render_template("siparis_ver.html", form=form, **ozet)

    urun_metni = ", ".join(
        f"{satir['adet']} x {satir['urun']['ad']}" for satir in ozet["sepet_urunleri"]
    )
    db = get_db()
    imlec = db.execute(
        "INSERT INTO siparisler (ad_soyad, telefon, adres, urunler, urun_toplami, "
        "kurye_ucreti, genel_toplam, durum, kurye_id, firin_id) "
        "VALUES (?, ?, ?, ?, ?, ?, ?, 'Bekliyor', NULL, ?)",
        (
            form["ad_soyad"],
            form["telefon"],
            form["adres"],
            urun_metni,
            ozet["urun_toplami"],
            ozet["kurye_ucreti"],
            ozet["genel_toplam"],
            ozet["firin"]["id"],
        ),
    )
    db.commit()
    siparis_id = imlec.lastrowid
    session.pop("sepet", None)
    flash("Siparişiniz alındı! Aşağıdan durumunu takip edebilirsiniz.", "basari")
    return redirect(url_for("siparis_takip", siparis_id=siparis_id))


@app.route("/siparis-takip/<int:siparis_id>")
def siparis_takip(siparis_id):
    # Takip sayfasında müşterinin kişisel bilgileri (ad, telefon, adres) gösterilmez.
    siparis = get_db().execute(
        "SELECT s.id, s.urunler, s.urun_toplami, s.kurye_ucreti, s.genel_toplam, "
        "s.durum, f.firin_adi FROM siparisler s "
        "LEFT JOIN firin_basvurulari f ON f.id = s.firin_id WHERE s.id = ?",
        (siparis_id,),
    ).fetchone()
    if siparis is None:
        flash("Sipariş bulunamadı. Numarayı kontrol edin.", "hata")
        return redirect(url_for("anasayfa"))
    return render_template("siparis_takip.html", siparis=siparis, durumlar=SIPARIS_DURUMLARI)


@app.route("/api/siparis-durum/<int:siparis_id>")
def api_siparis_durum(siparis_id):
    satir = get_db().execute(
        "SELECT durum FROM siparisler WHERE id = ?", (siparis_id,)
    ).fetchone()
    if satir is None:
        return jsonify({"hata": "Sipariş bulunamadı."}), 404
    return jsonify({"durum": satir["durum"]})


# ---------------------------------------------------------------------------
# FIRINCI
# ---------------------------------------------------------------------------


@app.route("/firinci", methods=["GET", "POST"])
def firinci_basvuru():
    if request.method == "GET":
        return render_template("firinci.html", form={})

    form = {
        "firin_adi": metin_al("firin_adi", 100),
        "yetkili": metin_al("yetkili", 100),
        "telefon": metin_al("telefon", 30),
        "adres": metin_al("adres", 300),
        "acilis": metin_al("acilis", 5),
        "kapanis": metin_al("kapanis", 5),
        "bolgeler": metin_al("bolgeler", 300),
        "kullanici_adi": metin_al("kullanici_adi", 50),
    }
    sifre = request.form.get("sifre") or ""

    def hata(mesaj):
        flash(mesaj, "hata")
        return render_template("firinci.html", form=form)

    if not all(form.values()) or not sifre:
        return hata("Lütfen tüm alanları doldurun.")
    acilis, kapanis = saat_coz(form["acilis"]), saat_coz(form["kapanis"])
    if acilis is None or kapanis is None:
        return hata("Açılış ve kapanış saatini doğru girin.")
    if acilis == kapanis:
        return hata("Açılış ve kapanış saati aynı olamaz.")
    if len(sifre) < 6:
        return hata("Şifre en az 6 karakter olmalı.")
    if kullanici_adi_kullaniliyor_mu("firin_basvurulari", form["kullanici_adi"]):
        return hata("Bu kullanıcı adı zaten kullanılıyor. Başka bir tane seçin.")

    db = get_db()
    db.execute(
        "INSERT INTO firin_basvurulari (firin_adi, yetkili, telefon, adres, saatler, "
        "bolgeler, kullanici_adi, sifre, durum) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'Bekliyor')",
        (
            form["firin_adi"],
            form["yetkili"],
            form["telefon"],
            form["adres"],
            f"{acilis // 60:02d}:{acilis % 60:02d} - {kapanis // 60:02d}:{kapanis % 60:02d}",
            form["bolgeler"],
            form["kullanici_adi"],
            generate_password_hash(sifre),
        ),
    )
    db.commit()
    flash("Başvurunuz alındı. Yönetici onayladıktan sonra giriş yapabilirsiniz.", "basari")
    return redirect(url_for("firinci_giris"))


@app.route("/firinci-giris", methods=["GET", "POST"])
def firinci_giris():
    if request.method == "POST":
        kayit, mesaj = giris_dene(
            "firin_basvurulari", metin_al("kullanici_adi", 50), request.form.get("sifre") or ""
        )
        if kayit is not None:
            session["firin_id"] = kayit["id"]
            return redirect(url_for("firinci_panel"))
        flash(mesaj, "hata")
    return render_template("firinci_giris.html")


@app.route("/firinci-cikis")
def firinci_cikis():
    session.pop("firin_id", None)
    flash("Çıkış yaptınız.", "bilgi")
    return redirect(url_for("firinci_giris"))


def firin_siparis_listesi(firin_id):
    """Fırıncının sadece KENDİ siparişleri. Müşterinin telefonu/adresi verilmez."""
    satirlar = get_db().execute(
        "SELECT id, ad_soyad, urunler, genel_toplam, durum FROM siparisler "
        "WHERE firin_id = ? ORDER BY id DESC LIMIT 100",
        (firin_id,),
    ).fetchall()
    return [
        {
            "id": s["id"],
            "ad_soyad": s["ad_soyad"],
            "urunler": s["urunler"],
            "toplam": tl_filtresi(s["genel_toplam"]),
            "durum": s["durum"],
            "sinif": DURUM_SINIFI.get(s["durum"], "bekliyor"),
        }
        for s in satirlar
    ]


@app.route("/firinci-panel")
@giris_gerekli("firin")
def firinci_panel():
    firin = g.kullanici
    return render_template(
        "firinci_panel.html",
        firin=firin,
        acik=firin_acik_mi(firin["saatler"]),
        siparisler=firin_siparis_listesi(firin["id"]),
    )


@app.route("/firinci-durum/<int:siparis_id>", methods=["POST"])
@giris_gerekli("firin")
def firinci_durum(siparis_id):
    yeni = request.form.get("durum", "")
    eski = FIRIN_GECISLERI.get(yeni)
    if eski is None:
        flash("Geçersiz işlem.", "hata")
        return redirect(url_for("firinci_panel"))

    db = get_db()
    # firin_id kontrolü sayesinde fırıncı başka fırının siparişini değiştiremez.
    imlec = db.execute(
        "UPDATE siparisler SET durum = ? WHERE id = ? AND firin_id = ? AND durum = ?",
        (yeni, siparis_id, g.kullanici["id"], eski),
    )
    db.commit()
    if imlec.rowcount == 1:
        flash(f"Sipariş #{siparis_id} durumu: {yeni}", "basari")
    else:
        flash("Bu sipariş güncellenemedi. Sayfayı yenileyip tekrar deneyin.", "hata")
    return redirect(url_for("firinci_panel"))


@app.route("/api/firin-siparisleri")
@giris_gerekli("firin", api=True)
def api_firin_siparisleri():
    return jsonify({"siparisler": firin_siparis_listesi(g.kullanici["id"])})


# ---------------------------------------------------------------------------
# KURYE
# ---------------------------------------------------------------------------


@app.route("/kurye", methods=["GET", "POST"])
def kurye_basvuru():
    if request.method == "GET":
        return render_template("kurye.html", form={}, araclar=ARACLAR)

    form = {
        "ad_soyad": metin_al("ad_soyad", 100),
        "telefon": metin_al("telefon", 30),
        "yas": metin_al("yas", 3),
        "ilce": metin_al("ilce", 100),
        "arac": metin_al("arac", 30),
        "kullanici_adi": metin_al("kullanici_adi", 50),
    }
    sifre = request.form.get("sifre") or ""

    def hata(mesaj):
        flash(mesaj, "hata")
        return render_template("kurye.html", form=form, araclar=ARACLAR)

    if not all(form.values()) or not sifre:
        return hata("Lütfen tüm alanları doldurun.")
    try:
        yas = int(form["yas"])
    except ValueError:
        return hata("Yaşınızı rakamla yazın.")
    if yas < 18:
        return hata("Kurye olmak için 18 yaşında veya daha büyük olmalısınız.")
    if form["arac"] not in ARACLAR:
        return hata("Listeden bir araç seçin.")
    if len(sifre) < 6:
        return hata("Şifre en az 6 karakter olmalı.")
    if kullanici_adi_kullaniliyor_mu("kurye_basvurulari", form["kullanici_adi"]):
        return hata("Bu kullanıcı adı zaten kullanılıyor. Başka bir tane seçin.")

    db = get_db()
    db.execute(
        "INSERT INTO kurye_basvurulari (ad_soyad, telefon, yas, ilce, arac, "
        "kullanici_adi, sifre, durum) VALUES (?, ?, ?, ?, ?, ?, ?, 'Bekliyor')",
        (
            form["ad_soyad"],
            form["telefon"],
            yas,
            form["ilce"],
            form["arac"],
            form["kullanici_adi"],
            generate_password_hash(sifre),
        ),
    )
    db.commit()
    flash("Başvurunuz alındı. Yönetici onayladıktan sonra giriş yapabilirsiniz.", "basari")
    return redirect(url_for("kurye_giris"))


@app.route("/kurye-giris", methods=["GET", "POST"])
def kurye_giris():
    if request.method == "POST":
        kayit, mesaj = giris_dene(
            "kurye_basvurulari", metin_al("kullanici_adi", 50), request.form.get("sifre") or ""
        )
        if kayit is not None:
            session["kurye_id"] = kayit["id"]
            return redirect(url_for("kurye_panel"))
        flash(mesaj, "hata")
    return render_template("kurye_giris.html")


@app.route("/kurye-cikis")
def kurye_cikis():
    session.pop("kurye_id", None)
    flash("Çıkış yaptınız.", "bilgi")
    return redirect(url_for("kurye_giris"))


def kurye_siparis_verileri(kurye_id):
    """Kuryenin paneli için: alınabilecek siparişler + kuryenin kendi siparişleri."""
    db = get_db()
    uygun = db.execute(
        "SELECT s.id, s.adres, s.urunler, s.genel_toplam, f.firin_adi, "
        "f.adres AS firin_adres FROM siparisler s "
        "LEFT JOIN firin_basvurulari f ON f.id = s.firin_id "
        "WHERE s.durum = 'Hazır' AND s.kurye_id IS NULL ORDER BY s.id"
    ).fetchall()
    benim = db.execute(
        "SELECT s.id, s.ad_soyad, s.telefon, s.adres, s.urunler, s.genel_toplam, "
        "s.durum, f.firin_adi, f.adres AS firin_adres FROM siparisler s "
        "LEFT JOIN firin_basvurulari f ON f.id = s.firin_id "
        "WHERE s.kurye_id = ? "
        "ORDER BY CASE WHEN s.durum = 'Teslim Edildi' THEN 1 ELSE 0 END, s.id DESC "
        "LIMIT 50",
        (kurye_id,),
    ).fetchall()
    return {
        "uygun_siparisler": [
            {
                "id": s["id"],
                "adres": s["adres"],
                "urunler": s["urunler"],
                "toplam": tl_filtresi(s["genel_toplam"]),
                "firin_adi": s["firin_adi"] or "",
                "firin_adres": s["firin_adres"] or "",
            }
            for s in uygun
        ],
        "benim_siparislerim": [
            {
                "id": s["id"],
                "ad_soyad": s["ad_soyad"],
                "telefon": s["telefon"],
                "adres": s["adres"],
                "urunler": s["urunler"],
                "toplam": tl_filtresi(s["genel_toplam"]),
                "durum": s["durum"],
                "sinif": DURUM_SINIFI.get(s["durum"], "bekliyor"),
                "firin_adi": s["firin_adi"] or "",
                "firin_adres": s["firin_adres"] or "",
            }
            for s in benim
        ],
    }


@app.route("/kurye-panel")
@giris_gerekli("kurye")
def kurye_panel():
    return render_template(
        "kurye_panel.html",
        kurye=g.kullanici,
        veri=kurye_siparis_verileri(g.kullanici["id"]),
    )


@app.route("/kurye-al/<int:siparis_id>", methods=["POST"])
@giris_gerekli("kurye")
def kurye_al(siparis_id):
    db = get_db()
    # Koşullu UPDATE: iki kurye aynı anda basarsa sadece biri başarılı olur.
    imlec = db.execute(
        "UPDATE siparisler SET kurye_id = ?, durum = 'Kurye Aldı' "
        "WHERE id = ? AND kurye_id IS NULL AND durum = 'Hazır'",
        (g.kullanici["id"], siparis_id),
    )
    db.commit()
    if imlec.rowcount == 1:
        flash(f"Sipariş #{siparis_id} sana atandı.", "basari")
    else:
        flash("Bu sipariş artık alınamaz. Başka bir kurye almış olabilir.", "hata")
    return redirect(url_for("kurye_panel"))


@app.route("/kurye-durum/<int:siparis_id>", methods=["POST"])
@giris_gerekli("kurye")
def kurye_durum(siparis_id):
    yeni = request.form.get("durum", "")
    eski = KURYE_GECISLERI.get(yeni)
    if eski is None:
        flash("Geçersiz işlem.", "hata")
        return redirect(url_for("kurye_panel"))

    db = get_db()
    # kurye_id kontrolü sayesinde kurye başkasının siparişini değiştiremez.
    imlec = db.execute(
        "UPDATE siparisler SET durum = ? WHERE id = ? AND kurye_id = ? AND durum = ?",
        (yeni, siparis_id, g.kullanici["id"], eski),
    )
    db.commit()
    if imlec.rowcount == 1:
        flash(f"Sipariş #{siparis_id} durumu: {yeni}", "basari")
    else:
        flash("Bu sipariş güncellenemedi. Sayfayı yenileyip tekrar deneyin.", "hata")
    return redirect(url_for("kurye_panel"))


@app.route("/api/kurye-siparisleri")
@giris_gerekli("kurye", api=True)
def api_kurye_siparisleri():
    return jsonify(kurye_siparis_verileri(g.kullanici["id"]))


# ---------------------------------------------------------------------------
# ADMIN
# ---------------------------------------------------------------------------
# İlk sürümde basit admin hesabı. Ortam değişkeniyle değiştirilebilir:
#   ADMIN_KULLANICI ve ADMIN_SIFRE


def admin_bilgileri():
    return (
        os.environ.get("ADMIN_KULLANICI", "admin"),
        os.environ.get("ADMIN_SIFRE", "1234"),
    )


@app.route("/admin", methods=["GET", "POST"])
def admin_giris():
    if session.get("admin") is True:
        return redirect(url_for("admin_paneli"))
    if request.method == "POST":
        kullanici, sifre = admin_bilgileri()
        girilen_kullanici = metin_al("kullanici_adi", 50).encode("utf-8")
        girilen_sifre = (request.form.get("sifre") or "").encode("utf-8")
        kullanici_dogru = hmac.compare_digest(girilen_kullanici, kullanici.encode("utf-8"))
        sifre_dogru = hmac.compare_digest(girilen_sifre, sifre.encode("utf-8"))
        if kullanici_dogru and sifre_dogru:
            session["admin"] = True
            return redirect(url_for("admin_paneli"))
        flash("Kullanıcı adı veya şifre hatalı.", "hata")
    return render_template("admin_giris.html")


@app.route("/admin-cikis")
def admin_cikis():
    session.pop("admin", None)
    flash("Çıkış yaptınız.", "bilgi")
    return redirect(url_for("admin_giris"))


@app.route("/admin-paneli")
@giris_gerekli("admin")
def admin_paneli():
    db = get_db()
    siralama = (
        "ORDER BY CASE durum WHEN 'Bekliyor' THEN 0 WHEN 'Onaylandı' THEN 1 ELSE 2 END, id DESC"
    )
    firinlar = db.execute(
        "SELECT id, firin_adi, yetkili, telefon, adres, saatler, bolgeler, "
        f"kullanici_adi, durum FROM firin_basvurulari {siralama}"
    ).fetchall()
    kuryeler = db.execute(
        "SELECT id, ad_soyad, telefon, yas, ilce, arac, kullanici_adi, durum "
        f"FROM kurye_basvurulari {siralama}"
    ).fetchall()
    siparisler = db.execute(
        "SELECT s.id, s.ad_soyad, s.telefon, s.adres, s.urunler, s.genel_toplam, "
        "s.durum, s.kurye_id, f.firin_adi FROM siparisler s "
        "LEFT JOIN firin_basvurulari f ON f.id = s.firin_id "
        "ORDER BY s.id DESC LIMIT 100"
    ).fetchall()
    return render_template(
        "admin.html", firinlar=firinlar, kuryeler=kuryeler, siparisler=siparisler
    )


ADMIN_ISLEMLERI = {"onayla": "Onaylandı", "reddet": "Reddedildi"}


def admin_durum_degistir(tablo, kayit_id, islem):
    yeni_durum = ADMIN_ISLEMLERI.get(islem)
    if yeni_durum is None:
        flash("Geçersiz işlem.", "hata")
        return redirect(url_for("admin_paneli"))
    db = get_db()
    imlec = db.execute(f"UPDATE {tablo} SET durum = ? WHERE id = ?", (yeni_durum, kayit_id))
    db.commit()
    if imlec.rowcount == 1:
        flash(f"Kayıt #{kayit_id} durumu: {yeni_durum}", "basari")
    else:
        flash("Kayıt bulunamadı.", "hata")
    return redirect(url_for("admin_paneli"))


@app.route("/admin/firin/<int:kayit_id>/<islem>", methods=["POST"])
@giris_gerekli("admin")
def admin_firin_islem(kayit_id, islem):
    # Fırın silinmez; "Reddedildi" yapılır (güvenli ve geri alınabilir).
    return admin_durum_degistir("firin_basvurulari", kayit_id, islem)


@app.route("/admin/kurye/<int:kayit_id>/<islem>", methods=["POST"])
@giris_gerekli("admin")
def admin_kurye_islem(kayit_id, islem):
    return admin_durum_degistir("kurye_basvurulari", kayit_id, islem)


# ---------------------------------------------------------------------------
# HATA SAYFALARI
# ---------------------------------------------------------------------------


@app.errorhandler(404)
def sayfa_bulunamadi(hata):
    return render_template("hata.html", mesaj="Aradığınız sayfa bulunamadı."), 404


@app.errorhandler(405)
def yontem_izinli_degil(hata):
    return render_template("hata.html", mesaj="Bu adres bu şekilde açılamaz."), 405


@app.errorhandler(500)
def sunucu_hatasi(hata):
    return render_template("hata.html", mesaj="Beklenmeyen bir hata oluştu. Lütfen tekrar deneyin."), 500


# Uygulama (gunicorn dahil) başlarken veritabanı hazır olsun.
veritabani_hazirla()

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    app.run(host="127.0.0.1", port=port, debug=True)
